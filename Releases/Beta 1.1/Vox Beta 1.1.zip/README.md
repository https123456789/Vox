# Vox

Vox is a voxel based game.

![Beta 1.0](<Releases/Beta 1.0/Beta 1.0.png>)
*Beta 1.0 Screenshot*

## Controls

| Control | Key |
|---------|-----|
| Move forward.| w |
| Move backward. | s |
| Rotate left. | Arrow Left |
| Rotate right. | Arrow right |