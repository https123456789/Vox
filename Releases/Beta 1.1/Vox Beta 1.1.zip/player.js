/*class Player {
	constructor(xpos, ypos, zpos, width, height) {
		this.x = xpos;
		this.y = ypos;
		this.z = zpos;
		this.width = width;
		this.height height;
	}
}*/