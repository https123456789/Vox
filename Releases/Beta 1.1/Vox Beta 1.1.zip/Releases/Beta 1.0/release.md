# Vox Beta 1.0

![Beta 1.0 Screenshot](<Beta 1.0.png>)
*Beta 1.0 Screenshot*

![Beta 1.0 Debug On](<Beta 1.0 Debug On.png>)
*Beta 1.0 Screenshot - Debug Mode On*

## Features

- 10x10 area of cubes.
- Basic collision physics.
- Simple Debug Mode.

## Notes

- This is a pre-release.

## Release Frequency

New Beta releases will be made every couple days.

## Upcoming Features

- Block type (no texture though).
- Better collision physics.