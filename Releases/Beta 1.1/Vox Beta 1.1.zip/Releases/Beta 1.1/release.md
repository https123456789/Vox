# Vox Beta 1.1

![Beta 1.1 Screenshot](<Beta 1.1.png>)
*Beta 1.1 Screenshot*

![Beta 1.1 Debug On](<Beta 1.1 Debug On.png>)
*Beta 1.1 Screenshot - Debug Mode On*

## Features

- 10x10 area of cubes.
- 4 raised cubes for jumping on.
- Multi-Sided collision physics.
- Debug Mode.

## Notes

- This is a pre-release.

## Release Frequency

New Beta releases will be made every couple days.

## Upcoming Features

- Block type (no texture though).
- Better collision physics.